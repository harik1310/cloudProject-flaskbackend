\set check_id 'ACM.1'
\echo "Executing check ACM.1"
\ir ../queries/acm/certificates_should_be_renewed.sql
