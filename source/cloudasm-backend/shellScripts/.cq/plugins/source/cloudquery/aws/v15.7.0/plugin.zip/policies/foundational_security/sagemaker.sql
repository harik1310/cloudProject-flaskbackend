\set check_id 'SageMaker.1'
\echo "Executing check SageMaker.1"
\ir ../queries/sagemaker/sagemaker_notebook_instance_direct_internet_access_disabled.sql
