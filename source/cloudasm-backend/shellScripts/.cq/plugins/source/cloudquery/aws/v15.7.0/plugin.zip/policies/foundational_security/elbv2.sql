\set check_id 'ELBv2.1'
\echo "Executing check ELBv2.1"
\ir ../queries/elb/elbv2_redirect_http_to_https.sql
