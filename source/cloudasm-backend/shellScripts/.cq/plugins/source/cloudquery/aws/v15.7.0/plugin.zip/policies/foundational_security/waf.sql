\set check_id 'WAF.1'
\echo "Executing check WAF.1"
\ir ../queries/waf/waf_web_acl_logging_should_be_enabled.sql
