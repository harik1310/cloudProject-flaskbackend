\set check_id 'SNS.1'
\echo "Executing check SNS.1"
\ir ../queries/sns/sns_topics_should_be_encrypted_at_rest_using_aws_kms.sql
