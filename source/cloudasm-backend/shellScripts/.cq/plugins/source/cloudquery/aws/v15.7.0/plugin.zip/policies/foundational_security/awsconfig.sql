\set check_id 'Config.1'
\echo "Executing check Config.1"
\ir ../queries/config/enabled_all_regions.sql
