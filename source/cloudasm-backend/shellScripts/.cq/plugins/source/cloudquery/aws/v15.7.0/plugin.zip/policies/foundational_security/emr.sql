\set check_id 'EMR.1'
\echo "Executing check EMR.1"
\ir ../queries/emr/emr_cluster_master_nodes_should_not_have_public_ip_addresses.sql
