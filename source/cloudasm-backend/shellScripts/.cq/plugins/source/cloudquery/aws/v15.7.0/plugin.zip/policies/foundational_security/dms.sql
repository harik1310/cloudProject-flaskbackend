\set check_id 'DMS.1'
\echo "Executing check DMS.1"
\ir ../queries/dms/replication_not_public.sql
