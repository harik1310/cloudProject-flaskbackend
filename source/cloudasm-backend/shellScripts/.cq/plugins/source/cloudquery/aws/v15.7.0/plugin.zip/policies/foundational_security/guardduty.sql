\set check_id 'GuardDuty.1'
\echo "Executing check GuardDuty.1"
\ir ../queries/guardduty/detector_enabled.sql
