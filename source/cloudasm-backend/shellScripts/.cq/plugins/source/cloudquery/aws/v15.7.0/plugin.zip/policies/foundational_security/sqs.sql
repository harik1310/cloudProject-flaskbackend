\set check_id 'SQS.1'
\echo "Executing check SQS.1"
\ir ../queries/sqs/sqs_queues_should_be_encrypted_at_rest_using_aws_kms.sql
