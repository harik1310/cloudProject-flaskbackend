\set check_id 'AutoScaling.1'
\echo "Executing check AutoScaling.1"
\ir ../queries/autoscaling/autoscaling_groups_elb_check.sql
